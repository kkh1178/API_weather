

## WeatherPy

In this example, you'll be creating a Python script to visualize the weather of 500+ cities across the world of varying distance from the equator. To accomplish this, you'll be utilizing a [simple Python library](https://pypi.python.org/pypi/citipy), the [OpenWeatherMap API](https://openweathermap.org/api), and a little common sense to create a representative model of weather across world cities.

Your objective is to build a series of scatter plots to showcase the following relationships:

* Temperature (F) vs. Latitude
* Humidity (%) vs. Latitude
* Cloudiness (%) vs. Latitude
* Wind Speed (mph) vs. Latitude

Your final notebook must:

* Randomly select **at least** 500 unique (non-repeat) cities based on latitude and longitude.
* Perform a weather check on each of the cities using a series of successive API calls. 
* Include a print log of each city as it's being processed with the city number, city name, and requested URL.
* Save both a CSV of all data retrieved and png images for each scatter plot.

As final considerations:

* You must use the Matplotlib and Seaborn libraries.
* You must include a written description of three observable trends based on the data. 
* You must use proper labeling of your plots, including aspects like: Plot Titles (with date of analysis) and Axes Labels.
* You must include an exported markdown version of your Notebook called  `README.md` in your GitHub repository.  
* See [Example Solution](WeatherPy_Example.pdf) for a reference on expected format. 


```python
# Dependencies
import pandas as pd
import numpy as np
import requests
import json
from citipy import citipy
import os as os
import matplotlib.pyplot as plt
import csv as csv

# Google API Key
from config import api_key
```


```python
# randomly generate a list of lats and longs
# numpy.random.uniform(low=0.0, high=1.0, size=None)
lat = np.random.uniform(low=-90.00, high=90.00, size=600)
lon = np.random.uniform(low=-180.00, high=180.00, size=600)
```


```python
latlong = zip(lat, lon)
```


```python
# Use citipy to generate the a list of the closest cities to your random coordinates. 
cities = []
for c in latlong:
    cities.append(citipy.nearest_city(c[0], c[1]))

```


```python
city_name=[]
for city in cities:
    name = city.city_name
    city_name.append(name)
```


```python
# Use Openweather api to get the weather data needed from those cities.
url = "http://api.openweathermap.org/data/2.5/weather?"
temps = []
humid = []
clouds = []
winds = []
lats = []
lons = []
names = []

# Build query URL
for city in city_name:
    query_url = url + "appid=" + api_key + "&q=" + city + "&units=imperial"
    response = requests.get(query_url)
    if response.status_code == 200:
        response = response.json()
        temps.append(response["main"]["temp"])
        humid.append(response["main"]["humidity"])
        clouds.append(response["clouds"]["all"])
        winds.append(response["wind"]["speed"])
        lats.append(response["coord"]["lat"])
        lons.append(response["coord"]["lon"])
        names.append(response["name"])
```


```python
weather = pd.DataFrame({"City": names,
                        "Temperature (F)": temps,
                        "Humidity (%)": humid,
                        "Cloud Coverage (%)": clouds,
                        "Wind Speed (mph)": winds,
                        "Latitude": lats, 
                        "Longitude": lons
                       })
weather.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>City</th>
      <th>Cloud Coverage (%)</th>
      <th>Humidity (%)</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>Temperature (F)</th>
      <th>Wind Speed (mph)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Punta Arenas</td>
      <td>75</td>
      <td>93</td>
      <td>-53.16</td>
      <td>-70.91</td>
      <td>44.60</td>
      <td>4.70</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Port Alfred</td>
      <td>88</td>
      <td>96</td>
      <td>-33.59</td>
      <td>26.89</td>
      <td>65.91</td>
      <td>10.74</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Port Alfred</td>
      <td>88</td>
      <td>96</td>
      <td>-33.59</td>
      <td>26.89</td>
      <td>65.91</td>
      <td>10.74</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Busselton</td>
      <td>76</td>
      <td>100</td>
      <td>-33.64</td>
      <td>115.35</td>
      <td>59.52</td>
      <td>24.16</td>
    </tr>
    <tr>
      <th>4</th>
      <td>That Phanom</td>
      <td>88</td>
      <td>91</td>
      <td>16.94</td>
      <td>104.73</td>
      <td>75.18</td>
      <td>5.93</td>
    </tr>
  </tbody>
</table>
</div>




```python
len(weather)
```




    527




```python
# In [61]: df.plot.scatter(x='a', y='b');

weather.plot.scatter(x="Latitude", y="Temperature (F)", title="Temperature per Latitude")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x112f3e0b8>




![png](output_9_1.png)



```python
# * Humidity (%) vs. Latitude
weather.plot.scatter(x="Latitude", y="Humidity (%)", title="Humidity per Latitude")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1063029b0>




![png](output_10_1.png)



```python
# * Cloudiness (%) vs. Latitude
weather.plot.scatter(x="Latitude", y="Cloud Coverage (%)", title="Cloud Coverage per Latitude")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x112ef25c0>




![png](output_11_1.png)



```python
#  Wind Speed (mph) vs. Latitude
weather.plot.scatter(x="Latitude", y="Wind Speed (mph)", title="Wind Speed per Latitude")
```




    <matplotlib.axes._subplots.AxesSubplot at 0x1130a12b0>




![png](output_12_1.png)


### Observation 1: Yes, the temperature does increase significantly between -20 degrees and approx latitude 25 degrees.

### Observation 2: The wind speed seems to drop slightly as well. Lower wind speeds can make a hot climate feel even hotter. This may be based on the time of the year. Since at least latitudes 0 to 90 degrees is currently experiencing spring/early summer.

### Observation 3: The humidity seems to decrease for some areas the further away you get from the equator (0 degrees latitude). Maybe because temperature makes water evaporate? More analysis would be needed to find out why.
